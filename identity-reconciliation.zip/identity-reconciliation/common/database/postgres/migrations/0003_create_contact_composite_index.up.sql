CREATE INDEX idx_phone_number_link_precedence ON CONTACT (phone_number, link_precedence);
CREATE INDEX idx_email_link_precedence ON CONTACT (email, link_precedence);
