CREATE UNIQUE INDEX idx_unique_phone_number_email ON CONTACT (phone_number, email);
